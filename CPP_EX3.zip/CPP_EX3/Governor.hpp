// Governor.hpp
#ifndef GOVERNOR_HPP
#define GOVERNOR_HPP

#include "Player.hpp"

namespace coup {

    // The Governor class represents a special role in the game.
    // This role allows a player to collect extra coins via a "tax" action,
    // and also cancel ("undo") a blockable tax action done by another player.
    class Governor : public Player {
    public:
        // Constructor that initializes the Governor with a reference to the game and the player's name.
        Governor(Game& game, const std::string& name);

        // Performs the "tax" action: the Governor collects 3 coins.
        // This action can be blocked by some other roles.
        void tax() override;

        // Allows the Governor to undo a blockable tax action taken by another player.
        // Removes coins from the target and clears their pending tax state.
        void undo(Player& other) override;
    };
}

#endif

