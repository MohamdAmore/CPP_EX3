// Governor.hpp
#ifndef GOVERNOR_HPP
#define GOVERNOR_HPP

#include "Player.hpp"

namespace coup {
    class Governor : public Player {
    public:
        Governor(Game& game, const std::string& name);

        void tax() override;
        void undo(Player& other) override;
    };
}

#endif
