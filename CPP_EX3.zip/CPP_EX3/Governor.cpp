// Governor.cpp
#include "Governor.hpp"
#include <stdexcept>

using namespace std;

namespace coup {

    Governor::Governor(Game& game, const string& name)
        : Player(game, name) {
        role_name = "Governor";
    }

    void Governor::tax() {
        if (!alive) throw runtime_error("Governor is not alive.");
        if (game.turn() != name) throw runtime_error("Not Governor's turn.");
        if (coins_count >= 10) throw runtime_error("Must perform coup with 10+ coins.");

        add_coins(3);
        pending_blockable_tax = true;
        game.next_turn();
    }

    void Governor::undo(Player& other) {
        if (!other.is_alive()) throw runtime_error("Target player is not alive.");
        if (!other.pending_blockable_tax)
            throw runtime_error("Target did not perform a blockable tax action.");

        other.remove_coins(2);  // Reverses a normal tax of +2
        other.pending_blockable_tax = false;
    }

}
