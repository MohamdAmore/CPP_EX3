// Governor.cpp
#include "Governor.hpp"
#include "Game.hpp"
#include <stdexcept>

using namespace std;

namespace coup {

    // Constructor for the Governor role.
    // Initializes the player with the specified name and sets the role name.
    Governor::Governor(Game& game, const string& name)
        : Player(game, name) {
        role_name = "Governor";
    }

    // The Governor's special ability: collect 3 coins through a "tax" action.
    // This action is blockable by certain roles and is marked as pending for that purpose.
    void Governor::tax() {
        if (!alive)
            throw runtime_error("Governor is not alive.");
        if (game.turn() != name)
            throw runtime_error("Not Governor's turn.");
        if (coins_count >= 10)
            throw runtime_error("Must perform coup with 10+ coins.");

        add_coins(3);                      // Collect 3 coins
        pending_blockable_tax = true;     // Mark the action as blockable
        game.next_turn();                 // End Governor's turn
    }

    // Governor's counter-ability: undo a blockable tax action of another player.
    // Used to cancel 2 coins that were collected by a blockable tax.
    void Governor::undo(Player& other) {
        if (!other.is_alive())
            throw runtime_error("Target player is not alive.");
        if (!other.has_pending_blockable_tax())
            throw runtime_error("Target did not perform a blockable tax action.");

        other.remove_coins(2);                  // Remove the 2 coins from the taxed player
        other.clear_pending_blockable_tax();    // Clear the pending state
    }

}

