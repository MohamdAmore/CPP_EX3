// Game.hpp
#ifndef GAME_HPP
#define GAME_HPP

#include <string>
#include <vector>
#include <stdexcept>

namespace coup {
    class Player;

    class Game {
    private:
        std::vector<Player*> players_list;
        size_t current_turn;

    public:
        Game();
        std::string turn() const;
        std::vector<std::string> players() const;
        std::string winner() const;

        void add_player(Player* p);
        void eliminate_player(Player* p);
        void next_turn();
    };
}

#endif
