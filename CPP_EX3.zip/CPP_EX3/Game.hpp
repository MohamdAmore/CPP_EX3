// Game.hpp
#ifndef GAME_HPP
#define GAME_HPP

#include <string>
#include <vector>
#include <stdexcept>

namespace coup {

    class Player;  // Forward declaration to avoid circular dependency

    // The Game class manages overall game state:
    // - the list of players
    // - current player's turn
    // - tracking eliminations and winner
    class Game {
    private:
        std::vector<Player*> players_list;  // All players in the game
        size_t current_turn;                // Index of the current player's turn

    public:
        // Constructor initializes an empty game
        Game();

        // Returns the name of the player whose turn it is
        std::string turn() const;

        // Returns a list of names of all currently active (alive) players
        std::vector<std::string> players() const;

        // Returns the name of the last surviving player (the winner)
        // Throws if the game is not yet finished
        std::string winner() const;

        // Checks if the given player is the current active player
        bool is_active(const Player& p) const;

        // Adds a player to the game
        // Throws an error if there are already 6 players
        void add_player(Player* p);

        // Marks a player as eliminated (used internally)
        void eliminate_player(Player* p);

        // Advances the turn to the next alive player
        void next_turn();
    };
}

#endif

