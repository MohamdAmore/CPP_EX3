// Baron.cpp
#include "Baron.hpp"
#include "Game.hpp"
#include <stdexcept>

using namespace std;

namespace coup {

    // Constructor for the Baron role.
    // Sets the player's role to "Baron" and registers them in the game.
    Baron::Baron(Game& game, const string& name)
        : Player(game, name) {
        role_name = "Baron";
    }

    // Special action for the Baron: invest.
    // If the Baron has at least 3 coins, they can invest to get 6 coins.
    // This action ends the turn.
    void Baron::invest() {
        if (!alive) throw runtime_error("Baron is not alive.");
        if (game.turn() != name) throw runtime_error("Not Baron's turn.");
        if (coins_count < 3) throw runtime_error("Not enough coins to invest.");
        if (coins_count >= 10) throw runtime_error("Must coup with 10+ coins.");

        remove_coins(3);
        add_coins(6);
        game.next_turn();
    }

    // Called when the Baron is sanctioned.
    // Even when sanctioned, the Baron still earns 1 coin.
    void Baron::on_sanction() {
        add_coins(1);
    }

}

