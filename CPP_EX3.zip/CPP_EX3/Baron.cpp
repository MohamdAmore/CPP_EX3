// Baron.cpp
#include "Baron.hpp"
#include <stdexcept>

using namespace std;

namespace coup {

    Baron::Baron(Game& game, const string& name)
        : Player(game, name) {
        role_name = "Baron";
    }

    void Baron::invest() {
        if (!alive) throw runtime_error("Baron is not alive.");
        if (game.turn() != name) throw runtime_error("Not Baron's turn.");
        if (coins_count < 3) throw runtime_error("Not enough coins to invest.");
        if (coins_count >= 10) throw runtime_error("Must coup with 10+ coins.");

        remove_coins(3);
        add_coins(6);
        game.next_turn();
    }

    void Baron::on_sanction() {
        // Baron gets 1 coin even when sanctioned
        add_coins(1);
    }

}
