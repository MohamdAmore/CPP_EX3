// Merchant.cpp
#include "Merchant.hpp"
#include <stdexcept>

using namespace std;

namespace coup {

    Merchant::Merchant(Game& game, const string& name)
        : Player(game, name) {
        role_name = "Merchant";
    }

    void Merchant::gather() {
        if (!alive) throw runtime_error("Merchant is not alive.");
        if (game.turn() != name) throw runtime_error("Not Merchant's turn.");

        if (coins_count >= 3) {
            add_coins(1); // Passive bonus
        }

        add_coins(1); // Standard gather
        game.next_turn();
    }

    void Merchant::tax() {
        if (!alive) throw runtime_error("Merchant is not alive.");
        if (game.turn() != name) throw runtime_error("Not Merchant's turn.");

        if (coins_count >= 3) {
            add_coins(1); // Passive bonus
        }

        add_coins(2); // Standard tax
        pending_blockable_tax = true;
        game.next_turn();
    }

    void Merchant::on_arrest() {
        // Merchant pays 2 coins to bank instead of 1 to attacker
        remove_coins(2);
    }

}
