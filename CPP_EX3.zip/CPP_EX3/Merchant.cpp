// Merchant.cpp
#include "Merchant.hpp"
#include "Game.hpp"
#include <stdexcept>

using namespace std;

namespace coup {

    // Constructor for the Merchant role.
    // Initializes the player and sets their role name.
    Merchant::Merchant(Game& game, const string& name)
        : Player(game, name) {
        role_name = "Merchant";
    }

    // The gather() function gives the Merchant 1 coin normally,
    // but if they already have at least 3 coins, they get an additional bonus coin.
    // This ability encourages saving money for extra gain.
    void Merchant::gather() {
        if (!alive) throw runtime_error("Merchant is not alive.");
        if (game.turn() != name) throw runtime_error("Not Merchant's turn.");

        if (coins_count >= 3) {
            add_coins(1); // Bonus coin for being wealthy
        }

        add_coins(1); // Standard gather income
        game.next_turn();
    }

    // The tax() function gives the Merchant 2 coins like a regular role,
    // and a bonus 1 coin if they already have 3 or more coins.
    // The tax is marked as blockable until the next turn.
    void Merchant::tax() {
        if (!alive) throw runtime_error("Merchant is not alive.");
        if (game.turn() != name) throw runtime_error("Not Merchant's turn.");

        if (coins_count >= 3) {
            add_coins(1); // Bonus for having savings
        }

        add_coins(2); // Standard tax gain
        pending_blockable_tax = true; // Can be undone by certain roles
        game.next_turn();
    }

    // on_arrest() is triggered when the Merchant is arrested.
    // Unlike most roles that lose 1 coin, the Merchant loses 2 coins directly to the bank.
    void Merchant::on_arrest() {
        remove_coins(2); // Higher penalty on arrest
    }

}

