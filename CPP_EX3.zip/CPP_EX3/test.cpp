#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "Game.hpp"
#include "Governor.hpp"
#include "Spy.hpp"
#include "Baron.hpp"
#include "General.hpp"
#include "Judge.hpp"
#include "Merchant.hpp"

using namespace coup;

TEST_CASE("Basic game flow and player turns") {
    Game g;
    Governor a(g, "Alice");
    Spy b(g, "Bob");
    Baron c(g, "Charlie");

    CHECK(g.players().size() == 3);
    CHECK(g.turn() == "Alice");

    a.gather();  // +1
    CHECK(a.coins() == 1);
    CHECK(g.turn() == "Bob");

    b.tax();  // +2
    CHECK(b.coins() == 2);
    CHECK(g.turn() == "Charlie");

    c.gather();
    CHECK(c.coins() == 1);
    CHECK(g.turn() == "Alice");
}

TEST_CASE("Governor tax and undo") {
    Game g;
    Governor gov(g, "Gov");
    Spy spy(g, "Spy");

    gov.tax();  // +3
    CHECK(gov.coins() == 3);

    spy.tax();  // +2 sets pending_blockable_tax
    CHECK(spy.coins() == 2);

    gov.undo(spy);  // remove spy's tax
    CHECK(spy.coins() == 0);
}

TEST_CASE("Baron invest") {
    Game g;
    Baron baron(g, "Baron");
    Governor gov(g, "Gov");

    baron.add_coins(3);
    baron.invest();
    CHECK(baron.coins() == 6);
}

TEST_CASE("General blocks coup and arrests refund") {
    Game g;
    Governor gov(g, "Gov");
    General gen(g, "Gen");

    gov.add_coins(10);
    gov.coup(gen);  // simulate
    gen.revive();
    gen.add_coins(7);  // rollback
    CHECK(gen.is_alive());
    CHECK(gen.coins() == 7);
}

TEST_CASE("Judge undo bribe and sanction logic") {
    Game g;
    Judge judge(g, "Judge");
    Spy spy(g, "Spy");

    // Advance turns to reach Spy
    while (g.turn() != spy.get_name()) {
        g.next_turn();
    }
    spy.tax();  // simulate bribe action

    // Advance to Judge
    while (g.turn() != judge.get_name()) {
        g.next_turn();
    }

    judge.undo_bribe(spy);
    CHECK(spy.coins() == 0);
}


TEST_CASE("Merchant passive income and arrest") {
    Game g;
    Merchant m(g, "Merch");

    m.add_coins(3);
    m.gather();  // +1 bonus +1 gather = +2
    CHECK(m.coins() == 5);

    m.on_arrest();
    CHECK(m.coins() == 3);
}

TEST_CASE("Edge Cases and Invalid Actions") {
    Game g;
    Governor gov(g, "Gov");
    Spy spy(g, "Spy");
    Merchant merchant(g, "Merchant");

    // Not player's turn
    CHECK_THROWS(spy.gather());

    // Not enough coins to bribe
    CHECK_THROWS(gov.bribe());

    // Must coup when having 10 or more coins
    gov.add_coins(10);
    CHECK_THROWS(gov.gather());
    CHECK_THROWS(gov.tax());
}

TEST_CASE("Spy reveal and block_arrest") {
    Game g;
    Spy spy(g, "Spy");
    Governor gov(g, "Gov");

    gov.add_coins(3);
    spy.reveal(gov);  // Just output

    CHECK_NOTHROW(spy.block_arrest(gov));  // Simulated hook
}


TEST_CASE("Arrest logic and repeated arrest prevention") {
    Game g;
    Governor gov(g, "Gov");
    Spy spy(g, "Spy");

    gov.add_coins(5);
    spy.add_coins(2);
    gov.arrest(spy);
    CHECK(gov.coins() == 6);
    CHECK(spy.coins() == 1);

    // Try arresting same target again — should throw
    CHECK_THROWS(gov.arrest(spy));
}
