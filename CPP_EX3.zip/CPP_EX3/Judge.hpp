#pragma once
#include "Player.hpp"

namespace coup {

    // The Judge class represents a special role in the game,
    // inheriting common behavior from the base Player class.
    class Judge : public Player {
    public:
        // Constructor: initializes the Judge with a reference to the game and their name.
        Judge(Game& game, const std::string& name);

        // Virtual destructor for safe cleanup and inheritance handling.
        ~Judge() override;

        // Overrides the base class undo method.
        // Allows the Judge to reverse an effect on another player (basic version).
        void undo(Player& target) override;

        // A specific function allowing the Judge to undo a bribe
        // (or other blockable action) performed by the target player.
        void undo_bribe(Player& target);
    };

}

