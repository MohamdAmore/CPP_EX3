// Baron.hpp
#ifndef BARON_HPP
#define BARON_HPP

#include "Player.hpp"

namespace coup {

    // The Baron class represents a player with a special "invest" ability.
    // Inherits from Player and overrides some behavior.
    class Baron : public Player {
    public:
        // Constructor that initializes the Baron with a game reference and a name.
        Baron(Game& game, const std::string& name);

        // Baron’s special move: spend 3 coins to gain 6.
        void invest();

        // If the Baron gets sanctioned, they still earn 1 coin.
        void on_sanction() override;
    };

}

#endif

