#include "Player.hpp"
#include "Game.hpp"
#include <stdexcept>
#include <iostream>

using namespace std;

namespace coup {

    // Constructor that adds the player to the game and sets up default values
    Player::Player(Game& game, const string& name) :
        game(game), name(name), coins_count(0), alive(true),
        role_name("Player"), pending_blockable_tax(false) {
        game.add_player(this);
    }

    string Player::get_name() const {
        return name;
    }

    int Player::coins() const {
        return coins_count;
    }

    bool Player::is_alive() const {
        return alive;
    }

    string Player::role() const {
        return role_name;
    }

    // Player takes 1 coin if not sanctioned and it's their turn
    void Player::gather() {
        if (!alive) throw runtime_error("Player is not alive.");
        if (game.turn() != name) throw runtime_error("Not player's turn.");
        if (coins_count >= 10) throw runtime_error("Must perform coup with 10+ coins.");
        if (sanctioned) throw runtime_error("You are sanctioned and cannot gather.");

        add_coins(1);
        game.next_turn();
    }

    // Player gets 2 coins — this action can be blocked (some roles can undo it)
    void Player::tax() {
        if (!alive) throw runtime_error("Player is not alive.");
        if (game.turn() != name) throw runtime_error("Not player's turn.");
        if (coins_count >= 10) throw runtime_error("Must perform coup with 10+ coins.");
        if (sanctioned) throw runtime_error("You are sanctioned and cannot tax.");

        add_coins(2);
        pending_blockable_tax = true;
        game.next_turn();
    }

    // Default implementation of undo (override in specific roles)
    void Player::undo(Player&) {
        throw runtime_error("This player cannot undo actions.");
    }

    // Placeholder for roles that override this to block actions
    void Player::block() {
        // Does nothing by default
    }

    // Perform a coup — costs 7 coins, eliminates the target
    void Player::coup(Player& target) {
        if (!alive) throw runtime_error("Player is not alive.");
        if (game.turn() != name) throw runtime_error("Not player's turn.");
        if (coins_count < 7) throw runtime_error("Not enough coins to coup.");
        if (!target.is_alive()) throw runtime_error("Target already out.");

        remove_coins(7);
        target.eliminate();
        game.eliminate_player(&target);
        game.next_turn();
    }

    void Player::add_coins(int amount) {
        coins_count += amount;
    }

    void Player::remove_coins(int amount) {
        if (coins_count < amount) throw runtime_error("Not enough coins.");
        coins_count -= amount;
    }

    void Player::eliminate() {
        alive = false;
    }

    // Bribe allows player to act twice in one turn — costs 4 coins
    void Player::bribe() {
        if (!alive) throw runtime_error("Player is not alive.");
        if (game.turn() != name) throw runtime_error("Not player's turn.");
        if (coins_count < 4) throw runtime_error("Not enough coins to bribe.");
        if (bribed_this_turn) throw runtime_error("Already bribed this turn.");

        remove_coins(4);
        bribed_this_turn = true;
        // After bribe, player can perform another action — handled by caller
    }

    // Arrest another player — only if they weren’t just arrested and are not protected
    void Player::arrest(Player& target) {
        if (!alive || !target.is_alive()) throw runtime_error("Both players must be alive.");
        if (game.turn() != name) throw runtime_error("Not player's turn.");
        if (target.get_name() == last_arrest_target) throw runtime_error("Cannot arrest same player twice in a row.");
        if (target.arrest_blocked) throw runtime_error("Target is protected from arrest.");

        target.remove_coins(1);
        add_coins(1);
        target.on_arrest();
        last_arrest_target = target.get_name();
        game.next_turn();
    }

    // Sanction blocks certain actions on the next turn (like gather/tax)
    void Player::sanction(Player& target) {
        if (!alive || !target.is_alive()) throw runtime_error("Both players must be alive.");
        if (game.turn() != name) throw runtime_error("Not player's turn.");
        if (coins_count < 3) throw runtime_error("Not enough coins to sanction.");

        remove_coins(3);
        target.sanctioned = true;
        target.on_sanction();
        game.next_turn();
    }

    // Indicates if this player performed a tax that can be undone
    bool Player::has_pending_blockable_tax() const {
        return pending_blockable_tax;
    }

    // Clears the flag for blockable tax actions
    void Player::clear_pending_blockable_tax() {
        pending_blockable_tax = false;
    }

    // Resets state for a new turn
    void Player::start_turn() {
        bribed_this_turn = false;
        arrest_blocked = false;
        if (sanctioned) {
            sanctioned = false;  // Sanctions only block one turn
        }
    }

    // Default handler for being arrested — specific roles may override
    void Player::on_arrest() {
        // Does nothing by default
    }

    // Default handler for being sanctioned — specific roles may override
    void Player::on_sanction() {
        // Does nothing by default
    }

    void Player::mark_as_eliminated() {
        alive = false;
    }

    void Player::revive() {
        alive = true;
    }

    // Returns a reference to the game this player belongs to
    Game& Player::get_game() const {
        return game;
    }
}

