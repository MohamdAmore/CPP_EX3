// Player.cpp
#include "Player.hpp"
#include "Game.hpp"
#include <stdexcept>
#include <iostream>

using namespace std;

namespace coup {

    Player::Player(Game& game, const string& name) :
        game(game), name(name), coins_count(0), alive(true),
        role_name("Player"), pending_blockable_tax(false) {
        game.add_player(this);
    }

    string Player::get_name() const {
        return name;
    }

    int Player::coins() const {
        return coins_count;
    }

    bool Player::is_alive() const {
        return alive;
    }

    string Player::role() const {
        return role_name;
    }

    void Player::gather() {
        if (!alive) throw runtime_error("Player is not alive.");
        if (game.turn() != name) throw runtime_error("Not player's turn.");
        if (coins_count >= 10) throw runtime_error("Must perform coup with 10+ coins.");

        add_coins(1);
        game.next_turn();
    }

    void Player::tax() {
        if (!alive) throw runtime_error("Player is not alive.");
        if (game.turn() != name) throw runtime_error("Not player's turn.");
        if (coins_count >= 10) throw runtime_error("Must perform coup with 10+ coins.");

        add_coins(2);
        pending_blockable_tax = true;
        game.next_turn();
    }

    void Player::undo(Player& other) {
        throw runtime_error("This player cannot undo actions.");
    }

    void Player::block() {
        // Default does nothing
    }

    void Player::coup(Player& target) {
        if (!alive) throw runtime_error("Player is not alive.");
        if (game.turn() != name) throw runtime_error("Not player's turn.");
        if (coins_count < 7) throw runtime_error("Not enough coins to coup.");
        if (!target.is_alive()) throw runtime_error("Target already out.");

        remove_coins(7);
        target.eliminate();
        game.eliminate_player(&target);
        game.next_turn();
    }

    void Player::add_coins(int amount) {
        coins_count += amount;
    }

    void Player::remove_coins(int amount) {
        if (coins_count < amount) throw runtime_error("Not enough coins.");
        coins_count -= amount;
    }

    void Player::eliminate() {
        alive = false;
    }

    Game& Player::get_game() const {
        return game;
    }
}
