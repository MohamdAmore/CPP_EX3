#include "Game.hpp"
#include "Governor.hpp"
#include "Spy.hpp"
#include "Baron.hpp"
#include "General.hpp"
#include "Judge.hpp"
#include "Merchant.hpp"

#include <iostream>
#include <memory>
#include <map>
#include <limits>

using namespace std;
using namespace coup;

// Utility function to print the current state of the game,
// including the current turn and all active players with their roles and coin counts.
void print_state(Game& game, const map<string, shared_ptr<Player>>& players) {
    cout << "=========================" << endl;
    cout << "Current Turn: " << game.turn() << endl;
    cout << "Active Players:" << endl;
    for (auto& [name, p] : players) {
        if (p->is_alive()) {
            cout << "- " << name << " (" << p->role() << ") : " << p->coins() << " coins" << endl;
        }
    }
    cout << "=========================" << endl;
}

int main() {
    Game game;
    map<string, shared_ptr<Player>> players;

    // Initialize the game with a set of players, each with a unique role
    players["Moshe"] = make_shared<Governor>(game, "Moshe");
    players["Yossi"] = make_shared<Spy>(game, "Yossi");
    players["Meirav"] = make_shared<Baron>(game, "Meirav");
    players["Reut"] = make_shared<General>(game, "Reut");
    players["Gilad"] = make_shared<Judge>(game, "Gilad");
    // You can add a Merchant or other roles here if needed

    // Main game loop: continues until one player remains (a winner is declared)
    while (true) {
        try {
            print_state(game, players); // Show current game status
            string current = game.turn();
            auto player = players[current];

            cout << "Choose action for " << current << " (" << player->role() << "):" << endl;
            cout << "1. gather\n2. tax\n3. bribe\n4. arrest\n5. sanction\n6. coup\n> ";

            int choice;
            cin >> choice;

            if (choice == 1) {
                player->gather();  // Basic +1 coin
            } else if (choice == 2) {
                player->tax();  // Role-specific tax (usually +2 or +3)
            } else if (choice == 3) {
                player->bribe();  // Bribe action (may affect other players)
            } else if (choice == 4) {
                cout << "Target for arrest: ";
                string target;
                cin >> target;
                player->arrest(*players.at(target));  // Arrest a specific player
            } else if (choice == 5) {
                cout << "Target for sanction: ";
                string target;
                cin >> target;
                player->sanction(*players.at(target));  // Sanction a player
            } else if (choice == 6) {
                cout << "Target for coup: ";
                string target;
                cin >> target;
                player->coup(*players.at(target));  // Forcefully eliminate a player
            } else {
                cout << "Invalid choice." << endl;
            }

        } catch (exception& e) {
            cerr << "Error: " << e.what() << endl;  // Handle invalid moves gracefully
        }

        // Check if the game has ended
        try {
            cout << "Winner: " << game.winner() << " 🎉" << endl;
            break;
        } catch (...) {
            // No winner yet, continue the game
        }
    }

    return 0;
}

