// Game.cpp
#include "Game.hpp"
#include "Player.hpp"
#include <stdexcept>

using namespace std;

namespace coup {

    Game::Game() : current_turn(0) {}

    void Game::add_player(Player* p) {
        if (players_list.size() >= 6) throw runtime_error("Too many players.");
        players_list.push_back(p);
    }

    vector<string> Game::players() const {
        vector<string> names;
        for (auto* p : players_list) {
            if (p->is_alive()) names.push_back(p->get_name());
        }
        return names;
    }

    string Game::turn() const {
        if (players_list.empty()) throw runtime_error("No players in game.");
        size_t count = 0, index = current_turn;
        while (!players_list[index]->is_alive()) {
            index = (index + 1) % players_list.size();
            if (++count > players_list.size()) throw runtime_error("No alive players.");
        }
        return players_list[index]->get_name();
    }

    void Game::eliminate_player(Player* p) {
        // No need to remove from vector, just mark as dead
    }

    void Game::next_turn() {
    size_t n = players_list.size();
    for (size_t i = 1; i <= n; ++i) {
        size_t idx = (current_turn + i) % n;
        if (players_list[idx]->is_alive()) {
            current_turn = idx;
            players_list[idx]->start_turn(); // Reset per-turn flags
            return;
        }
    }
    throw runtime_error("No alive players left.");
}

    string Game::winner() const {
        string last;
        int count = 0;
        for (auto* p : players_list) {
            if (p->is_alive()) {
                ++count;
                last = p->get_name();
            }
        }
        if (count == 1) return last;
        throw runtime_error("Game is still ongoing.");
    }

}
