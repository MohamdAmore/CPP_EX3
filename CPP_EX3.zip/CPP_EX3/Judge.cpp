// Judge.cpp
#include "Judge.hpp"
#include <stdexcept>

using namespace std;

namespace coup {

    Judge::Judge(Game& game, const string& name)
        : Player(game, name) {
        role_name = "Judge";
    }

    void Judge::undo_bribe(Player& other) {
        if (!other.is_alive()) {
            throw runtime_error("Target player is not alive.");
        }

        // Assume we will have a boolean flag like `pending_bribe` in Player
        if (!other.pending_blockable_tax) { // placeholder — bribe logic not implemented yet
            throw runtime_error("Target did not perform bribe recently.");
        }

        other.remove_coins(4);
        other.pending_blockable_tax = false;
    }

    void Judge::on_sanction() {
        // Additional coin taken from sanctioner — logic handled in sanctioner's method
        // Here we could set a flag for use in that method
    }

}
