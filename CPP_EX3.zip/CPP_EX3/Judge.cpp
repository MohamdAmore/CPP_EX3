#include "Judge.hpp"
#include "Game.hpp"
#include <stdexcept>

using namespace std;

namespace coup {

    // Constructor for the Judge role.
    // Initializes the base Player class and sets the role name.
    Judge::Judge(Game& game, const string& name)
        : Player(game, name) {
        role_name = "Judge";
    }

    // Destructor for the Judge class.
    // Currently empty, but defined to avoid linker issues.
    Judge::~Judge() {}

    // A general undo function. For now, it gives the target player 1 coin.
    // This could be used to reverse some effect in the game logic.
    void Judge::undo(Player& target) {
        if (!alive)
            throw runtime_error("Player is not alive");
        if (!target.is_alive())
            throw runtime_error("Target is not alive");

        target.add_coins(1);  // Simplified undo effect
    }

    // Specific undo function for reversing a bribe.
    // If the target performed a blockable tax action (like bribe), it is canceled and coins are removed.
    // If not, but they have 4+ coins, we assume a bribe occurred and remove 4 coins.
    // If none of those conditions are met, an error is thrown.
    void Judge::undo_bribe(Player& target) {
        if (!target.is_alive()) {
            throw std::runtime_error("Target is not alive.");
        }

        if (target.has_pending_blockable_tax()) {
            target.remove_coins(2);
            target.clear_pending_blockable_tax();
        } else if (target.coins() >= 4) {
            target.remove_coins(4);  // Assume a bribe occurred
        } else {
            throw std::runtime_error("No bribe to undo.");
        }
    }

}

