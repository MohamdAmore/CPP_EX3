// Merchant.hpp
#ifndef MERCHANT_HPP
#define MERCHANT_HPP

#include "Player.hpp"

namespace coup {
    class Merchant : public Player {
    public:
        Merchant(Game& game, const std::string& name);

        void gather() override;
        void tax() override;
        void on_arrest() override;
    };
}

#endif
