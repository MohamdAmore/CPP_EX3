#ifndef MERCHANT_HPP
#define MERCHANT_HPP

#include "Player.hpp"
#include "Spy.hpp"

namespace coup {

class Merchant : public Player {
public:
    // Creates a Merchant player with a given name in the game
    Merchant(Game& game, const std::string& name);

    // Merchant gathers coins — if they already have 3 or more, they get an extra bonus
    void gather() override;

    // Merchant gets 2 coins from the bank, and another 1 if they already have 3 or more
    void tax() override;

    // If arrested, the Merchant loses 2 coins instead of just 1
    void on_arrest() override;

    // Lets the Merchant block a steal attempt by a Spy
    void block_steal(Spy& thief);
};

}

#endif

