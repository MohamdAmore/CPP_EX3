#include "Game.hpp"
#include "Governor.hpp"
#include "Spy.hpp"
#include "Baron.hpp"
#include "General.hpp"
#include "Judge.hpp"
#include "Merchant.hpp"

#include <iostream>
#include <vector>

using namespace std;
using namespace coup;

int main() {
    Game g;
    Governor gov(g, "Gov");
    Spy spy(g, "Spy");
    Baron baron(g, "Baron");
    General general(g, "General");
    Judge judge(g, "Judge");
    Merchant merchant(g, "Merchant");

    vector<string> players = g.players();
    cout << "Initial players: ";
    for (const auto& name : players) {
        cout << name << " ";
    }
    cout << endl;

    // Turn 1: Gov
    while (g.turn() != gov.get_name()) g.next_turn();
    gov.gather();

    // Turn 2: Spy
    while (g.turn() != spy.get_name()) g.next_turn();
    spy.tax();

    // Turn 3: Baron
    while (g.turn() != baron.get_name()) g.next_turn();
    baron.gather();

    // Turn 4: General
    while (g.turn() != general.get_name()) g.next_turn();
    general.gather();

    // Turn 5: Judge
    while (g.turn() != judge.get_name()) g.next_turn();
    judge.gather();

    // Turn 6: Merchant
    while (g.turn() != merchant.get_name()) g.next_turn();
    merchant.gather();

    // Turn 7: Gov again
    while (g.turn() != gov.get_name()) g.next_turn();
    gov.tax();

    // Print final coin counts
    cout << gov.get_name() << " has " << gov.coins() << " coins." << endl;
    cout << spy.get_name() << " has " << spy.coins() << " coins." << endl;
    cout << baron.get_name() << " has " << baron.coins() << " coins." << endl;
    cout << general.get_name() << " has " << general.coins() << " coins." << endl;
    cout << judge.get_name() << " has " << judge.coins() << " coins." << endl;
    cout << merchant.get_name() << " has " << merchant.coins() << " coins." << endl;

    return 0;
}

