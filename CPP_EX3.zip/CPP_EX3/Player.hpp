#ifndef PLAYER_HPP
#define PLAYER_HPP

#include <string>
#include <vector>
#include <memory>

namespace coup {

    class Game;

    // Base class for all player roles in the game.
    // Contains shared properties and default behaviors.
    class Player {
    protected:
        Game& game;                     // Reference to the game instance
        std::string name;              // Player's name
        int coins_count;               // Number of coins the player has
        bool alive;                    // Whether the player is still in the game
        std::string role_name;         // Role name (e.g., Governor, Spy, etc.)
        bool pending_blockable_tax;    // True if the player performed a tax action that can be undone
        bool bribed_this_turn = false; // True if the player already bribed this turn
        bool sanctioned = false;       // True if player was sanctioned last turn
        bool arrest_blocked = false;   // True if player is protected from arrest
        std::string last_arrest_target; // Last player this one arrested (used to prevent repeats)

    public:
        // Constructor
        Player(Game& game, const std::string& name);
        
        // Virtual destructor for polymorphism
        virtual ~Player() = default;

        // Get player's name
        std::string get_name() const;

        // Get current coin count
        int coins() const;

        // Check if player is alive
        bool is_alive() const;

        // Return the player's role name
        std::string role() const;

        // Action: Gain 1 coin
        virtual void gather();

        // Action: Gain 2 coins (can be blocked)
        virtual void tax();

        // Action: Eliminate another player (costs 7 coins)
        virtual void coup(Player& target);

        // Action: Attempt to bribe to play twice in a turn
        void bribe();

        // Action: Try to arrest another player (may give coins and block their turn)
        void arrest(Player& target);

        // Action: Sanction another player (blocks their next income/tax)
        void sanction(Player& target);

        // Called when player is arrested — can be overridden by roles
        virtual void on_arrest();

        // Called when player is sanctioned — can be overridden by roles
        virtual void on_sanction();

        // Called by the game when the turn starts — resets flags like sanction or bribe
        void start_turn();

        // Used by Judge or Governor to reverse specific actions
        virtual void undo(Player& other);

        // Used by some roles to block specific actions (default = no-op)
        virtual void block();

        // True if the player performed a tax action that can still be undone
        bool has_pending_blockable_tax() const;

        // Clears the undoable-tax flag (after it's undone or confirmed)
        void clear_pending_blockable_tax();

        // Used by General to mark someone as removed
        virtual void mark_as_eliminated();

        // Used by General to revive someone after coup
        virtual void revive();

        // Accessor for the game instance
        Game& get_game() const;

        // Helpers for adjusting coin count
        void add_coins(int amount);
        void remove_coins(int amount);

        // Marks player as no longer alive (used in coup or other eliminations)
        void eliminate();
    };

} // namespace coup

#endif

