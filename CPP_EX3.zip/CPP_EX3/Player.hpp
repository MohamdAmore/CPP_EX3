// Player.hpp
#ifndef PLAYER_HPP
#define PLAYER_HPP

#include <string>
#include <vector>
#include <memory>

namespace coup {
    class Game;

    class Player {
    protected:
        Game& game;
        std::string name;
        int coins_count;
        bool alive;
        std::string role_name;
        bool pending_blockable_tax;
        bool bribed_this_turn = false;
        bool sanctioned = false;
        bool arrest_blocked = false;
        std::string last_arrest_target;

    public:
        void bribe();
        void arrest(Player& target);
        void sanction(Player& target);
        Player(Game& game, const std::string& name);
        virtual ~Player() = default;

        std::string get_name() const;
        int coins() const;
        bool is_alive() const;
        std::string role() const;

        virtual void gather();          // +1 coin
        virtual void tax();             // +2 coins (default implementation)
        virtual void undo(Player& other); // Virtual: only some roles override
        virtual void block();           // default = do nothing
        virtual void on_arrest();    // Hook for role-specific override
        virtual void on_sanction();  // Hook for role-specific override
        void start_turn(); // reset sanction/bribe flags
        virtual void coup(Player& target); // -7 coins, eliminate player

        Game& get_game() const;

        void add_coins(int amount);
        void remove_coins(int amount);
        void eliminate();
    };
}

#endif
