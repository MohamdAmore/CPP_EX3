#include "General.hpp"
#include "Game.hpp"
#include <stdexcept>

namespace coup {

    // Constructor for the General role
    // Initializes the base Player class and sets the role name
    General::General(Game& game, const std::string& name)
        : Player(game, name) {
        role_name = "General";
    }

    // Special ability: block a coup against another player
    // This simulates "undoing" a coup by reviving the target and refunding coins
    void General::block_coup(Player& target) {
        if (!alive)
            throw std::runtime_error("General is not alive.");
        if (!target.is_alive())
            throw std::runtime_error("Target is not alive.");
        if (coins_count < 5)
            throw std::runtime_error("Not enough coins to block coup.");

        remove_coins(5);     // Pay to block
        target.revive();     // Revive the player
        target.add_coins(7); // Refund the coup cost
    }

    // Called when the General is arrested
    // General receives 1 coin compensation when sanctioned
    void General::on_arrest() {
        add_coins(1);
    }

}

