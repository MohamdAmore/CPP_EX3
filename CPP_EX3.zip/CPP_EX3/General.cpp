// General.cpp
#include "General.hpp"
#include <stdexcept>

using namespace std;

namespace coup {

    General::General(Game& game, const string& name)
        : Player(game, name) {
        role_name = "General";
    }

    void General::block_coup(Player& target) {
        if (!alive) throw runtime_error("General is not alive.");
        if (!target.is_alive()) throw runtime_error("Target is not alive.");
        if (coins_count < 5) throw runtime_error("Not enough coins to block coup.");

        remove_coins(5);

        // Cancel the coup effect. Could be tracked externally.
        // For now, assume that in Demo logic, coup doesn't proceed if this was called.
        target.add_coins(7); // Return coup cost to attacker (rollback behavior)
    }

    void General::on_arrest() {
        // General gets the arrested coin back
        add_coins(1);
    }

}
