// Spy.cpp
#include "Spy.hpp"
#include <iostream>
#include <stdexcept>

using namespace std;

namespace coup {

    // Spy constructor – sets up the player and assigns the role name
    Spy::Spy(Game& game, const string& name)
        : Player(game, name) {
        role_name = "Spy";
    }

    // Special ability: Spy can reveal how many coins another player has
    // Does not affect the game state, just prints to console
    void Spy::reveal(Player& other) const {
        if (!other.is_alive()) {
            throw runtime_error("Cannot reveal coins of a dead player.");
        }
        cout << other.get_name() << " has " << other.coins() << " coins." << endl;
    }

    // Spy can block an arrest attempt on another player
    // This doesn't cost anything and doesn't advance the turn
    void Spy::block_arrest(Player& other) {
        if (!alive || !other.is_alive()) {
            throw runtime_error("Spy or target is not alive.");
        }

        // We assume the 'block' function sets a flag or disables arrests temporarily
        other.block();
    }

}

