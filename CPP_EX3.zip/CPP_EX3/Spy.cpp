// Spy.cpp
#include "Spy.hpp"
#include <iostream>
#include <stdexcept>

using namespace std;

namespace coup {

    Spy::Spy(Game& game, const string& name)
        : Player(game, name) {
        role_name = "Spy";
    }

    void Spy::reveal(Player& other) const {
        if (!other.is_alive()) {
            throw runtime_error("Cannot reveal coins of a dead player.");
        }
        cout << other.get_name() << " has " << other.coins() << " coins." << endl;
    }

    void Spy::block_arrest(Player& other) {
        if (!alive || !other.is_alive()) {
            throw runtime_error("Spy or target is not alive.");
        }

        // Let's assume we add a flag in Player that disables arrest temporarily.
        // This method does not advance turn, and costs nothing.
        other.block();  // This method can later be overridden to apply effects.
    }
}
