// Spy.hpp
#ifndef SPY_HPP
#define SPY_HPP

#include "Player.hpp"

namespace coup {

    // The Spy role inherits from Player.
    // This role has two special actions:
    // - reveal: See another player's coin count.
    // - block_arrest: Prevent someone else from being arrested.
    class Spy : public Player {
    public:
        // Constructor – sets up the spy with the given name and game
        Spy(Game& game, const std::string& name);

        // View how many coins another player has
        void reveal(Player& other) const;

        // Prevent an arrest attempt on a target player
        void block_arrest(Player& other);
    };

}

#endif

